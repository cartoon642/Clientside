function meme(value){

    switch (value) {
    case "blue":
        alert ("like the sky");
        break; 
    case "red":
        alert ("like the blood of my enemies");
        break; 
    case "green":
        alert("dude weed");
        break; 
    case "pink":
        alert ("ok gay");
        break; 
    case "purple":
        alert("choke me daddy");
        break; 
    case "yellow":
        alert ("mmm gamer pee");
        break; 
    case "orange":
        alert ("pulse");
        break; 
    case "none":
        alert ("boring");
        break; 
    case "dont":
        alert ("xD")
        break; 
    default: 
        text = "";
             }
}